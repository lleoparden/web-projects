<?php
include 'db.php';

// Check for valid product ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid product ID.";
    exit;
}

$product_id = (int)$_GET['id'];

// Prepare the statement
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
if (!$stmt) {
    die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
}

// Bind parameters
$stmt->bind_param("i", $product_id);

// Execute the statement
if (!$stmt->execute()) {
    die("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
}

// Get the result
$result = $stmt->get_result();
if (!$result) {
    die("Get result failed: (" . $stmt->errno . ") " . $stmt->error);
}

// Fetch the product
$product = $result->fetch_assoc();
if (!$product) {
    echo "Product not found.";
    exit;
}

// Display product details
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo htmlspecialchars($product['NAME']); ?></title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .navbar-brand {
            float: left;
        }

        nav.main-navigation {
            position: relative;
            padding-bottom: 15px;
            padding-top: 5px;
            background-color: #262626;
        }

        nav.main-navigation ul.nav-list {
            padding-bottom: 20px;
            padding: 0;
            list-style: none;
            position: relative;
            text-align: right;
            margin-right: 20px;
        }

        .nav-list li.nav-list-item {
            display: inline-block;
            line-height: 40px;
            margin-left: 30px;
            margin-top: 15px;
        }

        a.nav-link {
            text-decoration: none;
            font-size: 18px;
            font-family: sans-serif;
            font-weight: 500;
            cursor: pointer;
            position: relative;
            color: #ffffff;
        }

        a.nav-link:hover {
            text-decoration: none;
            color: #FF730D;
        }

        @keyframes FadeIn {
            0% {
                opacity: 0;
                -webkit-transition-duration: 0.8s;
                transition-duration: 0.8s;
                -webkit-transform: translateY(-10px);
                -ms-transform: translateY(-10px);
                transform: translateY(-10px);
            }

            100% {
                opacity: 1;
                -webkit-transform: translateY(0);
                -ms-transform: translateY(0);
                transform: translateY(0);
                pointer-events: auto;
                transition: cubic-bezier(0.4, 0, 0.2, 1);
            }
        }

        .nav-list li {
            animation: FadeIn 1s cubic-bezier(0.65, 0.05, 0.36, 1);
            animation-fill-mode: both;
        }

        .nav-list li:nth-child(1) {
            animation-delay: .3s;
        }

        .nav-list li:nth-child(2) {
            animation-delay: .6s;
        }

        .nav-list li:nth-child(3) {
            animation-delay: .9s;
        }

        .nav-list li:nth-child(4) {
            animation-delay: 1.2s;
        }

        .nav-list li:nth-child(5) {
            animation-delay: 1.5s;
        }

        @keyframes fadeInUp {
            from {
                transform: translate3d(0, 40px, 0);
            }

            to {
                transform: translate3d(0, 0, 0);
                opacity: 1;
            }
        }

        @-webkit-keyframes fadeInUp {
            from {
                transform: translate3d(0, 40px, 0);
            }

            to {
                transform: translate3d(0, 0, 0);
                opacity: 1;
            }
        }

        .animated {
            animation-duration: 1s;
            animation-fill-mode: both;
            -webkit-animation-duration: 1s;
            -webkit-animation-fill-mode: both;
        }

        .animatedFadeInUp {
            opacity: 0;
        }

        .fadeInUp {
            opacity: 0;
            animation-name: fadeInUp;
            -webkit-animation-name: fadeInUp;
        }

        .call {
            background-color: white;
            color: black;
            padding: 10px;
        }

        .call:hover {
            background-color: #FF730D;
            color: white;
            text-decoration: none;
        }

        footer{
            position: relative;
            background-color: #262626;
            color: white;
            text-decoration: none;
            
        }

        .btn {
            background-color: rgb(1, 146, 127);
            color: white;
            padding: 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            text-align: center;
            padding-left: 20px;
            padding-right: 20px;
        }

        .product-info {
            padding-left: 30px;
            margin-top: 30px;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .product-info h1 {
            font-size: 32px;
            margin-bottom: 20px;
            color: #333;
        }

        .product-info p {
            font-size: 18px;
            color: #666;
            margin-bottom: 15px;
        }

        .product-info img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <nav class="main-navigation">
        <div class="navbar-header animated fadeInUp">
            <a href="home.html" class="navbar-brand">
                <img src="logo 1.png" alt="logo" style="float: left;">
            </a>
        </div>
        <ul class="nav-list">
            <li class="nav-list-item"><a href="" class="nav-link">Pricing</a></li>
            <li class="nav-list-item"><a href="category.php" class="nav-link">Category</a></li>
            <li class="nav-list-item"><a href="allProducts.html" class="nav-link">Products</a></li>
            <li class="nav-list-item"><a href="personaltrainers.html" class="nav-link">About Us</a></li>
            <li class="nav-list-item"><a href="login.php" class="nav-link">Log In</a></li>
            <li class="nav-list-item"><a href="contact.php" class="nav-link">Contact Us</a></li>
        </ul>
    </nav>

    <div class="product-info">
        <h1><?php echo htmlspecialchars($product['NAME']); ?></h1>
        <p><img src="<?php echo htmlspecialchars($product['img']); ?>" alt="Product Image"></p>
        <p>$<?php echo htmlspecialchars($product['price']); ?></p>
        <p><?php echo htmlspecialchars($product['description']); ?></p>
    </div>

    <br><br>
    <center>
        <button class="btn" onclick="window.location.href = 'category.php';">BACK TO CATEGORY</button>
    </center>
    <br><br>

    <center>
    <footer>
        <div class="container mt-5">
            <div class="row">
                <div class="col-sm-12 col-md-4">
                    <h6>Contact Us</h6>
                    <p>Phone: +37064444432</p>
                    <p>Email: info@movementlab.lt</p>
                </div>
                <div class="col-sm-12 col-md-4">
                    <h6>Follow Us</h6>
                    <p>Facebook | Twitter | Instagram</p>
                </div>
                <div class="col-sm-12 col-md-4">
                    <h6>Address</h6>
                    <p>Vytenio g. 51, Vilnius</p>
                </div>
            </div>
        </div>
    </footer>
</center>
</body>
</html>
